﻿namespace _05.ListManipulationAdvanced
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToList();

            string input = "";

            while ((input = Console.ReadLine()) != "end")
            {
                string[] tokens = input.Split(" ")
                    .ToArray();
                string command = tokens[0];
                if (command == "Contains")//Contains {number}
                {
                    int item = int.Parse(tokens[1]);
                    if (numbers.Contains(item))
                    {
                        Console.WriteLine("Yes");
                    }
                    else
                    {
                        Console.WriteLine("No such number");
                    }

                }
                else if (command == "PrintEven")//PrintEven
                {
                    List<int> evenNumbers = new List<int>();
                    foreach (int number in numbers)
                    {
                        if (number % 2 == 0)
                        {
                            evenNumbers.Add(number);
                        }
                    }
                    Console.WriteLine(string.Join(" ", evenNumbers));

                }
                else if (command == "PrintOdd")//PrintOdd
                {
                    List<int> oddNumbers = new List<int>();
                    foreach (int number in numbers)
                    {
                        if (number % 2 == 1)
                        {
                            oddNumbers.Add(number);
                        }
                    }
                    Console.WriteLine(string.Join(" ", oddNumbers));
                }
                else if (command == "GetSum")//GetSum 
                {
                    int sum = 0;
                    foreach (int number in numbers)
                    {
                        sum += number;
                    }

                    Console.WriteLine(sum);
                }
                else if (command == "Filter")//Filter {condition} {number}
                {
                    string condition = tokens[1];
                    int number = int.Parse(tokens[2]);

                    if (condition == "<")
                    {
                        numbers.RemoveAll(x => x >= number);    
                        //for (int i = 0; i < numbers.Count; i++)
                        //{
                        //    int currentNum = numbers[i];
                        //    if (currentNum >= number)
                        //    {
                        //        numbers.Remove(currentNum);
                        //        i--;
                        //    }
                           
                        //}
                    }
                    else if (condition == "<=")
                    {
                        numbers.RemoveAll(x => x > number);
                        //for (int i = 0; i < numbers.Count; i++)
                        //{
                        //    int currentNum = numbers[i];
                        //    if (currentNum > number)
                        //    {
                        //        numbers.Remove(currentNum);
                        //        i--;
                        //    }

                        //}
                    }
                    else if (condition == ">")
                    {
                        numbers.RemoveAll(x => x <= number);
                        //for (int i = 0; i < numbers.Count; i++)
                        //{
                        //    int currentNum = numbers[i];
                        //    if (currentNum <= number)
                        //    {
                        //        numbers.Remove(currentNum);
                        //        i--;
                        //    }

                        //}
                    }
                    else if (condition == ">=")
                    {
                        numbers.RemoveAll(x => x < number);
                        //for (int i = 0; i < numbers.Count; i++)
                        //{
                        //    int currentNum = numbers[i];
                        //    if (currentNum < number)
                        //    {
                        //        numbers.Remove(currentNum);
                        //        i--;
                        //    }

                        //}
                    }


                }
            }
            Console.Write(string.Join(" ", numbers));
        }
        
    }
}

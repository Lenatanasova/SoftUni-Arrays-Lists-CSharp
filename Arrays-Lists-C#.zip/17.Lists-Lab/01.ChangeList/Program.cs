﻿namespace _01.ChangeList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToList();

            string input = " ";
            while ((input = Console.ReadLine()) != "end")
            {
                string[] parts = input.Split(" ");
                string operation = parts[0];

                if (operation == "Delete")
                {
                    DeleteOperation(numbers, parts);

                }
                else if (operation == "Insert")
                {
                    InsertOperation(numbers, parts);
                }
            }

            Console.Write(string.Join(" ", numbers));


        }

        private static void InsertOperation(List<int> numbers, string[] parts)
        {
            int index = int.Parse(parts[2]);
            int elementToBeInserted = int.Parse(parts[1]);
            numbers.Insert(index, elementToBeInserted);
        }

        private static void DeleteOperation(List<int> numbers, string[] parts)
        {
            int elementForRemoval = int.Parse(parts[1]);
            while (numbers.Contains(elementForRemoval))
            {
                numbers.Remove(elementForRemoval);
            }
        }
    }
}

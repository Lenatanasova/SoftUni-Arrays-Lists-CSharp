﻿using System.Threading.Channels;

namespace _04.ListManipulationBasics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToList();

            string input = "";
            while ((input = Console.ReadLine()) != "end")
            {
                string[] tokens = input.Split(" ");
                string operation = tokens[0];

                if (operation == "Add")//Add {number}
                {
                    int elementToAdd = int.Parse(tokens[1]);
                    numbers.Add(elementToAdd);
                }
                else if (operation == "Remove")//Remove {number}
                {
                    int elementToRemove = int.Parse(tokens[1]);
                    numbers.Remove(elementToRemove);

                }
                else if (operation == "RemoveAt")//RemoveAt {index} 
                {
                    int indexToRemoveAt = int.Parse(tokens[1]);
                    numbers.RemoveAt(indexToRemoveAt);
                }
                else if(operation == "Insert")//Insert {number} {index}
                {
                    int elementToInsert = int.Parse(tokens[1]);
                    int indexToInsertAt = int.Parse(tokens[2]);
                    numbers.Insert(indexToInsertAt, elementToInsert);
                }
            }

            Console.Write(string.Join(" ", numbers));
        }
    }
}

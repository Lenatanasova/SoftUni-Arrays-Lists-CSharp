﻿namespace _03.MergingLists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> firstRow = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToList();

            List<int> secondRow = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToList();

            List<int> output = new List<int>();

            int iterations = 0;

            if (firstRow.Count > secondRow.Count)
            {
                iterations = firstRow.Count;
            }
            else
            {
                iterations = secondRow.Count;
            }

            for(int i = 0; i < iterations; i++)
            {
                if (i <  firstRow.Count)
                {
                    int firstRowCurrElement = firstRow[i];
                    output.Add(firstRowCurrElement);
                }
                
                if (i < secondRow.Count)
                {
                    int secondRowCurrElement = secondRow[i];
                    output.Add(secondRowCurrElement);
                }
                
            }
            Console.WriteLine(string.Join(" ", output));

        }
    }
}

﻿namespace _18.Excercise_Arrays_Lists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToArray();

            List<int> results = new List<int>();

            int iterations = numbers.Length / 2;

            for (int i = 0; i < iterations; i++)
            {
                int currentNum = numbers[i] + numbers[numbers.Length - 1 - i];
                results.Add(currentNum);
            }
            if (numbers.Length % 2 != 0)
            {
                results.Add(numbers[numbers.Length / 2]);
            }

            Console.Write(string.Join(" ", results));

        }
    }
}

﻿using System;

namespace _05.EqualArrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToArray();
            int[] array2 = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToArray();

            for (int i = 0; i < array1.Length; i++)
            {
                int array1CurrentNum = array1[i];
                int array2CurrentNum = array2[i];

                if (array1CurrentNum != array2CurrentNum)
                {
                    Console.WriteLine("Arrays are not identical.");
                    return;
                }
            }
            Console.WriteLine("Arrays are identical.");


        }
    }
}

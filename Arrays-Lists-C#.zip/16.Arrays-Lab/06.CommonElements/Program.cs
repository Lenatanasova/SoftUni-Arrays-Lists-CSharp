﻿namespace _06.CommonElements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToArray();
            int[] array2 = Console.ReadLine()
                .Split(" ")
                .Select(int.Parse)
                .ToArray();

            //for (int i = 0; i < array1.Length; i++)
            //{
            //    int CurrentNum = array1[i];
            //    foreach(int number in array2)
            //    {
            //        if (CurrentNum == number)
            //        {
            //            Console.Write($"{number} ");
            //        }
            //    }

               
            //}
            foreach (int currentNumArray1 in array1)
            {
                foreach (int currentNumArray2 in array2)
                {
                    if(currentNumArray1 == currentNumArray2)
                    {
                        Console.Write($"{currentNumArray1} ");
                        break;
                    }
                }
            }
        }
    }
}
